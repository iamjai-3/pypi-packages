def cel_far(j):
    c_f = (j*9/5)+32
    return c_f

def far_cel(j):  
    f_c = (j-32)*5/9
    return f_c

def kel_cel(j):
    k_c = j-273.15
    return k_c

def cel_kel(j):
    c_k = j + 273.15
    return c_k

def kel_far(j):
    k_f = (j - 273.15) * 9/5 + 32
    return k_f

def far_kel(j):
    f_k = (j - 32) * 5/9 + 273.15
    return f_k
